#include <iostream>

using namespace std;

long long int store[100];

void addToNext(int n);

int main() {
    store[0] = store[1] = 1;
    int n;

    cout << "Please enter the number n:";
    cin >> n;

    for (int i = 2; i < n; i++) {
        addToNext(i);
    }

    cout << "n: " << store[n - 1] << "\tsum: " << store[n - 1] * 2 + store[n - 2] - 1 << endl;
}

void addToNext(int n) {
    store[n] = store[n - 1] + store[n - 2];
}