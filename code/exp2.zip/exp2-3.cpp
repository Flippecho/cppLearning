#include <iostream>
#include <algorithm>

using namespace std;

bool compare(const string& a, const string& b);

int main() {
    string store[5];

    for(auto & i : store) {
        cout << "Please enter the next string: " << endl;
        cin >> i;
    }

    sort(store, store + 5, compare);
    cout << endl;

    for(int i = 0; i < 5; i++) {
        cout << "String " << i + 1 << ": " << store[i] << endl;
    }
}

bool compare(const string& a, const string& b) {
    return a.length() < b.length();
}