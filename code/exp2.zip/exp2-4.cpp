#include <iostream>

using namespace std;

int main() {
    int n = 5, k = 3, result = 1;

    for (int i = n; i > n - k; i--) {
        result *= i;
    }

    cout << result << endl;
}