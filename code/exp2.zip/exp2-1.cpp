#include <iostream>
using namespace std;

int main() {
    int m = 100, n = 13;
    cout << m / n * n << endl;
}