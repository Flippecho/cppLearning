#include <iostream>

using namespace std;

class ABC {
private:
    int a, b, c;

public:
    ABC(int x, int y, int z) : a(x), b(y), c(z) {}

    friend ostream &operator << (ostream &out, ABC &f);
};

ostream &operator << (ostream &out, ABC &f) {
    out << "a = " << f.a << "\nb = " << f.b << "\nc = " << f.c << endl;
    return out;
}

int main() {
    ABC obj(10, 20, 30);
    cout << obj;
    // operator << reloaded, taking cout and obj as two parameters
    return 0;
}