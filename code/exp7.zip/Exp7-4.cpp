#include <iostream>
#include <iomanip>

using namespace std;

// Only year between [0, 9999] are supported, leap year considered up to 3200
class Date {
private:
    int year, month, day;
    int days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

public:
    Date(int y = 2012, int m = 1, int d = 1) {
        year = y < 0 ? 2012 : year % 10000;

        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0 && year % 3200 != 0)) {
            days[1] = 29;   // leap year
        } else {
            days[1] = 28;   // common year
        }

        month = m <= 0 ? 1 : m % 12 + 1;
        int max = days[month - 1];
        day = d <= 0 ? 1 : day % max + 1;
    }

    void setYear();

    void setMonth();

    void setDay();

    void reset() {
        setYear();
        setMonth();
        setDay();
    }

    void display() {
        cout << "Date: " << setfill('0')
             << setw(4) << year << "-" << setw(2) << month << "-" << setw(2) << day << endl;
    }

    friend bool operator==(Date &d1, Date &d2);

    friend bool operator>(Date &d1, Date &d2);

    friend bool operator<(Date &d1, Date &d2);

    friend bool operator!=(Date &d1, Date &d2);

    Date operator++() {
        selfIncrease();
        return *this;
    }

    Date operator++(int) {
        selfIncrease();
        return *this;
    }

    Date operator--() {
        selfDecrease();
        return *this;
    }

    Date operator--(int) {
        selfDecrease();
        return *this;
    }

    Date operator+=(int n);

    Date operator-=(int n);

    void selfIncrease() {
        if (day + 1 == days[month - 1]) {
            day = 1;
            if (month == 12) {
                month = 1;
                if (year == 9999) {
                    cerr << "Overflow: only year between [0, 9999] are supported." << endl;
                } else {
                    year++;
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0 && year % 3200 != 0)) {
                        days[1] = 29;   // leap year
                    } else {
                        days[1] = 28;   // common year
                    }
                }
            } else {
                month++;
            }
        } else {
            day++;
        }
    }

    void selfDecrease() {
        if (day == 1) {
            if (month == 1) {
                if (year == 0) {
                    cerr << "Overflow: only year between [0, 9999] are supported." << endl;
                    return;
                } else {
                    year--;
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0 && year % 3200 != 0)) {
                        days[1] = 29;   // leap year
                    } else {
                        days[1] = 28;   // common year
                    }
                }
                month = 12;
            } else {
                month--;
            }
            day = 31;
        } else {
            day--;
        }
    }
};

void Date::setYear() {
    int y;
    cout << "Please enter the year to set:" << endl;
    cin >> y;

    while (y < 0 || y > 9999) {
        cout << "Only year between [0, 9999] are supported, please enter the correct year:" << endl;
        cin >> y;
    }

    year = y;
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0 && year % 3200 != 0)) {
        days[1] = 29;   // leap year
    } else {
        days[1] = 28;   // common year
    }
}

void Date::setMonth() {
    int m;
    cout << "Please enter the month to set:" << endl;
    cin >> m;

    while (m < 1 || m > 12) {
        cout << "Only month between [1, 12] are supported, please enter the correct month:" << endl;
        cin >> m;
    }

    month = m;
}

void Date::setDay() {
    int d, max = days[month - 1];
    cout << "Please enter the day to set:" << endl;
    cin >> d;

    while (d < 1 || d > max) {
        cout << "Only day between [1, " << max << "] are supported, please enter the correct day:" << endl;
        cin >> d;
    }

    day = d;
}

bool operator==(Date &d1, Date &d2) {
    return d1.year == d2.year && d1.month == d2.month && d1.day == d2.day;
}

bool operator>(Date &d1, Date &d2) {
    return d1.year * 10000 + d1.month * 100 + d1.day > d2.year * 10000 + d2.month * 100 + d2.day;
}

bool operator<(Date &d1, Date &d2) {
    return d1.year * 10000 + d1.month * 100 + d1.day < d2.year * 10000 + d2.month * 100 + d2.day;
}

bool operator!=(Date &d1, Date &d2) {
    return d1.year != d2.year || d1.month != d2.month || d1.day != d2.day;
}

Date Date::operator+=(int n) {
    for (int i = 0; i < n; i++) {
        selfIncrease();
    }

    return *this;
}

Date Date::operator-=(int n) {
    for (int i = 0; i < n; i++) {
        selfDecrease();
    }

    return *this;
}

int main() {
    Date date(2022, 11, 25), date1, date2;
    date.display();
    cout << "\nResetting date..." << endl;
    date.reset();
    cout << "Date resetting done.\n" << endl;

    cout << "0:";
    date.display();
    cout << "1:";
    date1.display();
    cout << "2:";
    date2.display();
    cout << "date == date1: " << boolalpha << (date == date1) << endl;
    cout << "date1 == date2: " << (date1 == date2) << endl;
    cout << "date1 < date2: " << (date1 < date2) << endl;

    cout << "\ndate1 self increased." << endl;
    date1++;
    cout << "1:";
    date1.display();
    cout << "2:";
    date2.display();
    cout << "date1 > date2: " << (date1 > date2) << endl;

    cout << "\ndate2 self increased twice." << endl;
    date2 += 2;
    cout << "1:";
    date1.display();
    cout << "2:";
    date2.display();
    cout << "date1 < date2: " << (date1 < date2) << endl;
}