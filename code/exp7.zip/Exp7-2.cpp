#include <iostream>
#include <cmath>

#define PI acos(-1)

using namespace std;

class Point {
protected:
    double x, y;

public:
    Point() {
        cout << "Constructor Point() called." << endl;
    }

    virtual void set();

    virtual void display();
};

void Point::set() {
    cout << "Please enter the coordinate x of the point:";
    cin >> x;
    cout << "Please enter the coordinate y of the point:";
    cin >> y;
}

void Point::display() {
    cout << "(x, y) = (" << x << ", " << y << ")" << endl;
}

class Circle : public Point {
protected:
    double radius;

public:
    Circle() {
        cout << "Constructor Circle() called." << endl;
    }

    void set();

    virtual void display();
};

void Circle::set() {
    Point::set();
    cout << "Please enter the radius of the circle:";
    cin >> radius;
}

void Circle::display() {
    Point::display();
    cout << "radius = " << radius << endl;
    cout << "area = " << PI * radius * radius << endl;
}

class Cylinder : public Circle {
private:
    double height;

public:
    Cylinder() {
        cout << "Constructor Cylinder() called." << endl;
    }

    void set();

    virtual void display();
};

void Cylinder::set() {
    Circle::set();
    cout << "Please enter the height of the cylinder:";
    cin >> height;
}

void Cylinder::display() {
    Circle::display();
    cout << "height = " << height << endl;
    cout << "volume = " << PI * radius * radius * height << endl;
}

int main() {
    Point point, *p;
    Circle circle;
    Cylinder cylinder;

//    p = &point;
//    cout << "\nSetting info of the point..." << endl;
//    p->set();
//    cout << "\nShowing info of the point..." << endl;
//    p->display();
//
//    p = &circle;
//    cout << "\nSetting info of the circle..." << endl;
//    p->set();
//    cout << "\nShowing info of the circle..." << endl;
//    p->display();

    p = &cylinder;
    cout << "\nSetting info of the cylinder..." << endl;
    p->set();
    cout << "\nShowing info of the cylinder..." << endl;
    p->display();
}