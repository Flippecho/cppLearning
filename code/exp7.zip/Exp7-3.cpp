#include <iostream>

using namespace std;

class Employee {
protected:
    string name, id;
public:
    Employee(string n, string i) {
        name = n;
        id = i;
    }

    void setName(string n) {
        name = n;
    }

    string getName() {
        return name;
    }

    void setID(string i) {
        id = i;
    }

    string getID() {
        return id;
    }

    virtual double calcSalary() = 0;

    virtual void showInfo() {
        cout << "Name: " << name << "\tid: " << id;
    }

    virtual ~Employee() {
        cout << "Destructor ~Employee() called." << endl;
    }
};

class Manager : public Employee {
private:
    double salary;
public:
    Manager(string n, string i, double s) : Employee(n, i) {
        salary = s;
    };

    void setSalary(double s) {
        salary = s;
    }

    double getSalary() {
        return salary;
    }

    virtual double calcSalary() {
        return salary;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "Info of a manager:" << endl;
        Employee::showInfo();
        cout << "\t\tsalary: " << salary << "\n" << endl;
    }

    virtual ~Manager() {
        cout << "Destructor ~Manager() called." << endl;
    }
};

class Technician : public Employee {
private:
    int hours;
    double wage;

public:
    Technician(string n, string i, int h, double w) : Employee(n, i) {
        hours = h;
        wage = w;
    }

    void setHour(int h) {
        hours = h;
    }

    int getHour() {
        return hours;
    }

    void setWage(double w) {
        wage = w;
    }

    double getWage() {
        return wage;
    }

    virtual double calcSalary() {
        return wage * hours;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "Info of a technician: " << endl;
        Employee::showInfo();
        cout << "\t\twage: " << wage << "\tworking hour: " << hours << "\tsalary: " << calcSalary() << "\n" << endl;
    }

    virtual ~Technician() {
        cout << "Destructor ~Technician() called." << endl;
    }
};

int main() {
    Employee *p;
    Manager manager("ZhangSan", "001", 12000);
    Technician technician("LiSi", "002", 128, 100);

    p = &manager;
    p->showInfo();
    manager.setSalary(20000);
    p->showInfo();
    p = &technician;
    p->showInfo();
}