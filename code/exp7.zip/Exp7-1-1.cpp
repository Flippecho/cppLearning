#include <iostream>

using namespace std;

class Base {
protected:
    int n;

public:
    Base(int m) {
        n = m++;
    }

    virtual void g1() {
        cout << "Base::g1()..." << n << endl;
        g4();
    }

    virtual void g2() {
        cout << "Base::g2()..." << ++n << endl;
        g3();
    }

    virtual void g3() {
        cout << "Base::g3()..." << ++n << endl;
        g4();
    }

    virtual void g4() {
        cout << "Base::g4()..." << ++n << endl;
    }
};

class Derive : public Base {
private:
    int j;

public:
    Derive(int n1, int n2) : Base(n1) {
        j = n2;
    }

    void g1() {
        cout << "Derive::g1()..." << ++n << endl;
        g2();
    }

    void g3() {
        cout << "Derive::g2()..." << ++n << endl;
        g4();
    }
};

int main() {
    Derive dObj(1, 0);
    Base bObj = dObj;
    bObj.g1();
    cout << "--------------------" << endl;
    Base *bp = &dObj;
    bp->g1();
    cout << "--------------------" << endl;
    Base &bObj2 = dObj;
    bObj2.g1();
    cout << "--------------------" << endl;
    dObj.g1();
    return 0;
}