#include <iostream>

using namespace std;

class Employee {
protected:
    string name, id;
    int level;
    double salary;

public:
    Employee(string n, string i, int l) {
        name = n;
        id = i;
        level = l;
        salary = 0;
    }

    string getID() {
        return id;
    }

    virtual void calcSalary() = 0;

    virtual void showInfo() {
        cout << "Name: " << name << "\t id: " << id << "\tsalary(chinese yuan): " << salary;
    }
};

class Manager : public Employee {
public:
    Manager(string n, string i) : Employee(n, i, 4) {};

    virtual void calcSalary() {
        salary = 8000;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "\nInfo of a manager:" << endl;
        Employee::showInfo();
        cout << endl;
    }
};

class Technician : public Employee {
private:
    int hour;

public:
    Technician(string n, string i, int h = 0) : Employee(n, i, 3) {
        hour = h;
    }

    void setHour(int h) {
        hour = h;
    }

    virtual void calcSalary() {
        salary = 100 * hour;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "\nInfo of a technician: " << endl;
        Employee::showInfo();
        cout << "\t working hour: " << hour << endl;
    }
};

class Salesman : public Employee {
private:
    double sales;

public:
    Salesman *next;

    Salesman(string n, string i, double s = 0) : Employee(n, i, 1) {
        sales = s;
        next = nullptr;
    }

    void setSales(double s) {
        sales = 0;
    }

    double getSales() {
        return sales;
    }

    virtual void calcSalary() {
        salary = sales * 0.04;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "Info of a salesman: " << endl;
        Employee::showInfo();
        cout << "\tsales: " << sales << endl;
    }
};

class SalesManager : public Employee {
private:
    Salesman *head, *tail;
    int size;
    double sales;

public:
    SalesManager(string n, string i) : Employee(n, i, 3) {
        size = 0;
        head = new Salesman("head", "head");
        head->next = tail;
        tail = head;
        tail->next = nullptr;
    }

    void addSalesman(Salesman s) {
        tail->next = &s;
        tail = &s;
        size++;
    }

    void removeSalesman(Salesman s) {
        Salesman *p = head, *q;
        while (p->next != nullptr) {
            q = p;
            p = p->next;
            if (p->getID() == s.getID()) {
                q->next = p->next;
//                delete p;
                size--;
            }
        }
    }

    virtual void calcSalary() {
        Salesman *p;
        p = head;
        sales = 0;
        while (p->next != nullptr) {
            p = p->next;
            sales += p->getSales();
        }
        salary = 5000 + sales * 0.005;
    }

    virtual void showInfo() {
        calcSalary();
        cout << "Info of a sales manager: " << endl;
        Employee::showInfo();
        cout << "\temployee size: " << size << "\tsales: " << sales << endl;
    }
};

int main() {
    Manager manager("ZhangSan", "001");
    Technician technician("LiSi", "002", 128);
    Salesman p1("P1", "003", 3000), p2("P2", "004", 4000), p3("P3", "005", 5000);
    SalesManager salesManager("SunWu", "006");

    manager.showInfo();
    technician.showInfo();
    p1.showInfo();
    p2.showInfo();
    p3.showInfo();

    salesManager.addSalesman(p1);
    salesManager.addSalesman(p2);
    salesManager.addSalesman(p3);

    salesManager.showInfo();

    salesManager.removeSalesman(p2);

    salesManager.showInfo();
}