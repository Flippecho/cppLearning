#include <iostream>

using namespace std;

class Score {
private:
    int chinese, english, mathematics;

public:
    Score() {};

    Score(int c, int e, int m) {
        chinese = c;
        english = e;
        mathematics = m;
    }

    int sum() {
        return chinese + english + mathematics;
    }

    void print() {
        cout << "Chinese: " << chinese << "\tEnglish: " << english << "\tMathematics: " << mathematics << endl;
    }

    void modify(int c, int e, int m) {
        chinese = c;
        english = e;
        mathematics = m;
    }
};

class Student {
private:
    string id, name;
    Score score;

public:
    Student() {};

    Student(string i, string n, Score s) {
        id = i;
        name = n;
        score = s;
    }

    int sum() {
        return score.sum();
    }

    void print() {
        cout << "id: " << id << "\tname: " << name << "\ttotal: " << score.sum() << "\t";
        score.print();
    }

    void modify(string i, string n, Score s) {
        id = i;
        name = n;
        score = s;
    }
};

int main() {
    int size = 7;
    Student array[size];

    srand(time(nullptr));
    for (int i = 0; i < size; i++) {
        string id = to_string(i + 1);
        string name = "Student" + to_string(i + 1);
        int chinese = rand() % 101;
        int english = rand() % 101;
        int mathematics = rand() % 101;
        array[i] = Student(id, name, Score(chinese, english, mathematics));
    }

    for (int i = 0; i < size; i++) {
        array[i].print();
    }

    return 0;
}