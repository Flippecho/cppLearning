#include <iostream>

using namespace std;

class Publication {
protected:
    string title, name, date;
    double price;

public:
    Publication() {
        cout << "Publication constructor called." << endl;
        price = 0;
    };

    virtual void inputData() {
        cout << "Please enter the title: " << endl;
        getline(cin, title);
        cout << "Please enter the name: " << endl;
        getline(cin, name);
        cout << "Please enter the price(chinese yuan): " << endl;
        cin >> price;
        cin.get();
        cout << "Please enter the book publication date(e.g. yyyy-mm-dd): " << endl;
        getline(cin, date);
    }

    virtual void display() {
        cout << "title: " << title
             << "    name: " << name
             << "    price: " << price
             << "    date: " << date;
    }

    virtual ~Publication() {
        cout << "Publication destructor called." << endl;
    }
};

class Book : public Publication {
private:
    int page;

public:
    Book() {
        cout << "Book constructor called." << endl;
        page = 0;
    };

    void inputData() {
        cout << "\nYou are completing the book info: " << endl;
        Publication::inputData();
        cout << "Please enter the book page: " << endl;
        cin >> page;
        cin.get();
    }

    void display() {
        cout << "\nHere is the book info: " << endl;
        Publication::display();
        cout << "    page: " << page << endl;
    }

    virtual ~Book() {
        cout << "Book destructor called." << endl;
    }
};

class Tape : public Publication {
private:
    int playtime;

public:
    Tape() {
        cout << "Constructor Tape called." << endl;
        playtime = 0;
    }

    void inputData() {
        cout << "\nYou are completing the tape info: " << endl;
        Publication::inputData();
        cout << "Please enter the playtime(second): " << endl;
        cin >> playtime;
        cin.get();
    }

    void display() {
        cout << "\nHere is the tape info: " << endl;
        Publication::display();
        cout << "    playtime: " << playtime << endl;
    }

    virtual ~Tape() {
        cout << "Tape destructor called." << endl;
    }
};


int main() {
    Publication* p;
    Book book;
    Tape tape;
    
    p = &book;
    p->inputData();
    p->display();
    p = &tape;
    p->inputData();
    p->display();

    cout << endl;
    return 0;
}