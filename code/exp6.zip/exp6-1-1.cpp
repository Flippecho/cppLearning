#include <iostream>

using namespace std;

class A {
public:
    A() {
        cout << "A::A() called." << endl;
    }

    virtual ~A() {
        cout << "A::~A() called." << endl;
    }
};

class B : public A {
private:
    char *buf;

public:
    B(int i) {
        cout << "B::B() called." << endl;
        buf = new char[i];
    }

    virtual ~B() {
        cout << "B::~B() called." << endl;
    }
};

void fun(A *a) {
    cout << "May you succeed!" << endl;
    delete a;
}

int main() {
    A *a = new B(15);
    fun(a);
    return 0;
}