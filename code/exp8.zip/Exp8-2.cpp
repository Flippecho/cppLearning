#include <iostream>
#include <fstream>

using namespace std;

class Array {
private:
    int data[20];

public:
    Array() {
        for (int i = 0; i < 20; i++) {
            data[i] = 0;
        }
    }

    int getNumber(Array &a, int k) {
        return a.data[k];
    }

    void getData();

    void max_min(int &max, int &min);

    void putData(int &max, int &min);
};

void Array::getData() {
    ifstream infile("IN.DAT", ios::in);
    if (!infile) {
        cerr << "open error!" << endl;
        abort();
    }

    for (int i = 0; i < 20; i++) {
        infile >> data[i];
    }

    infile.close();
}

void Array::max_min(int &max, int &min) {
    int tMax = data[0], tMin = data[0];
    for (int i = 1; i < 20; i++) {
        if (data[i] > tMax) {
            tMax = data[i];
        }

        if (data[i] < tMin) {
            tMin = data[i];
        }
    }
    max = tMax;
    min = tMin;
}

void Array::putData(int &max, int &min) {
    ofstream outfile("OUT.DAT", ios::out);
    if (!outfile) {
        cerr << "open error!" << endl;
        abort();
    }

    outfile << "(max, min) = (" << max << ", " << min << ")";
    outfile.close();
}

int main() {
    ofstream initFile("IN.DAT", ios::out);
    if(!initFile) {
        cerr << "open error!" << endl;
        abort();
    }

    srand(time(nullptr));
    for(int i = 0; i < 20; i++) {
        initFile << rand() % 100 << " ";
    }
    initFile.close();

    Array array;
    int max, min;
    array.getData();
    cout << "The first-read number is: " << array.getNumber(array, 0) << endl;
    array.max_min(max, min);
    array.putData(max, min);

    ifstream testFile("OUT.DAT", ios::in);
    if(!testFile) {
        cerr << "open error!" << endl;
    }
    string test;
    getline(testFile, test);
    testFile.close();

    cout << "File [OUT.DAT] read:\t" << test << endl;
}