#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

class Worker {
private:
    int number, age;
    char name[20];
    double salary;

public:
    Worker() = default;

    Worker(int num, const char *n, int a, double sal) {
        number = num;
        strcpy_s(name, n);
        age = a;
        salary = sal;
    }

    void display() {
        cout << number << "\t" << name << "\t" << age << "\t" << salary << endl;
    }
};

int main() {
    ofstream out("Worker.dat", ios::out | ios::binary);
    Worker man[] = {
            Worker(1, "ZhangSan", 23, 2320),
            Worker(2, "LiSi", 32, 2321),
            Worker(3, "WangWu", 34, 2322),
            Worker(4, "LiuLiu", 27, 2324),
            Worker(5, "XiaoHong", 23, 2325),
            Worker(6, "HuangMing", 50, 2326)
    };

    for (int i = 0; i < 6; i++) {
        out.write((char *) &man[i], sizeof(man[i]));
    }

    out.close();

    Worker s1;
    Worker list[10];


    ifstream in("Worker.dat", ios::in | ios::binary);

    in.seekg(0, ios::beg);
    in.read((char *) &list, sizeof(list));
    for (int i = 0; i < 6; ++i) {
        list[i].display();
    }
    // skip first two men
//    in.seekg(2 * (sizeof(s1)), ios::beg);
//    in.read((char *) &s1, sizeof(s1));
//    s1.display();
//
//    in.seekg(0, ios::beg);
//    in.read((char *) &s1, sizeof(s1));
//    s1.display();

    in.close();

    return 0;
}