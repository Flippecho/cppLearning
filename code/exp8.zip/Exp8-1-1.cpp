#include <iostream>
#include <fstream>

using namespace std;

int main() {
    fstream out, in;

    out.open("a.dat", ios::out);
    out << "on fact\n" << "operating file \n" << "is the same as inputing/outputing data on screen...\n";
    out.close();
    // one blank line in the file [a.dat]

    char buffer[80];
    in.open("a.dat", ios::in);
    while (!in.eof()) {
        in.getline(buffer, 80);
        cout << buffer << endl;
    }
    // two blank line in the console
    return 0;
}