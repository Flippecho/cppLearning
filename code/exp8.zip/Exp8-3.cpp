#include <iostream>
#include <fstream>

using namespace std;

class Student {
private:
    string name, school, major, clase, telephone, address, postcode;

public:
    Student() {

    }

    void getInfo();

    void showInfo();
};

void Student::getInfo() {
    cout << "Please enter the name: " << endl;
    getline(cin, name);
    // Too much information to get, therefore, only read in the name for example
    school = "CSU";
    major = "CS";
    clase = "2006";
    telephone = "1-707-733-6644";
    address = "Mars";
    postcode = "314500";
}

void Student::showInfo() {
    cout << "Name: " << name
         << "\nSchool: " << school
         << "\nMajor: " << major
         << "\nClass: " << clase
         << "\nTelephone: " << telephone
         << "\nAddress: " << address
         << "\nPostcode: " << postcode << endl;
}

int main() {
    int size = 10;
//    Student array[10];
    Student *array = new Student[size];
    for (int i = 0; i < size; i++) {
        cout << "\nCompleting the info of No." << i + 1 << " student..." << endl;
        array[i].getInfo();
    }

    cout << "\nWriting info to the file [address.dat]..." << endl;

    ofstream outfile("address.dat", ios::out | ios::binary);
    if (!outfile) {
        cerr << "open error!" << endl;
        abort();
    }

    outfile.write((char *) &array, sizeof(array));
    outfile.close();

    cout << "\nReading info from the file [address.dat]..." << endl;

//    Student array2[10];
    Student *array2 = new Student[size];
    ifstream infile("address.dat", ios::in | ios::binary);
    if (!infile) {
        cerr << "open error!" << endl;
        abort();
    }

    infile.read((char *) &array2, sizeof(array2));
    infile.close();

    for (int i = 0; i < 10; ++i) {
        array2[i].showInfo();
    }
}