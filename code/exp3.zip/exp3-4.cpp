#include <iostream>
#define N 10
using namespace std;

void max(int a[][N], int m, int &row, int &col);

int main() {
    int m = 10, a[10][10], row, col;

    srand(time(nullptr));
    for(int i = 0; i < m; i++) {
        for(int j = 0; j < N; j++) {
            a[i][j] = rand() % 10000;
//            cout << a[i][j] << "\t";
        }
//        cout << endl;
    }

    max(a, m, row, col);

    cout << "(max, row, col) = (" << a[row][col] << ", " << row << ", " << col << ")" << endl;
}

void max(int a[][N], int m, int &row, int &col) {
    int max = a[0][0];
    row = col = 0;
    for(int i = 0; i < m; i++) {
        for(int j = 0; j < N; j++) {
            if(a[i][j] > max) {
                max = a[i][j];
                row = i;
                col = j;
            }
        }
    }
}