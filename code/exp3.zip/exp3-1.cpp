#include <iostream>

using namespace std;

int max2(int a, int b);
int max3d(int a, int b, int c = -32768);
int max3(int a, int b, int c);

int main() {
    cout << "max3d(1, 2, 3) = " << max3d(1, 2, 3) << endl;
    cout << "max3(1, 2, 3) = " << max3(1, 2, 3) << endl;
    cout << "max3d(1, 2) = " << max3d(1, 2) << endl;
//    cout << "max(1, 2) = " << max3(1, 2) << endl;
}

int max2(int a, int b) {
    return a > b ? a : b;
}

int max3d(int a, int b, int c) {
    return max2(max2(a, b), c);
}

int max3(int a, int b, int c) {
    return max2(max2(a, b), c);
}
