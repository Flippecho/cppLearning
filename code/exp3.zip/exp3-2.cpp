#include <iostream>

using namespace std;

int mystrchr(char string[], char c);

int main() {
    cout << "find h in hello world: " << mystrchr("hello world", 'h') << endl;
    cout << "find w in hello world: " << mystrchr("hello world", 'w') << endl;
    cout << "find h in goodbye world: " << mystrchr("goodbye world", 'h') << endl;
}

int mystrchr(char string[], char c) {
    int index = 0;
    while (string[index] != '\0') {
        if (string[index] == c) {
            return index;
        }
        index++;
    }
    return -1;
}