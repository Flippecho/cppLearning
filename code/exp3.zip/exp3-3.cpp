#include <iostream>
#include <cmath>

using namespace std;

double getDistance(int a, int b, int c, int d);

double getDistance(double a, double b, double c, double d);

int main() {
    cout << "The distance between (1, 2) and (3, 4) is: " << getDistance(1, 2, 3, 4) << endl;
    cout << "The distance between (1.2, 3.4) and (5.6, 7.8) is: " << getDistance(1.2, 3.4, 5.6, 7.8) << endl;
}

double getDistance(int a, int b, int c, int d) {
    return sqrt(pow(abs(a - c), 2) + pow(abs(b - d), 2));
}

double getDistance(double a, double b, double c, double d) {
    return sqrt(pow(abs(a - c), 2) + pow(abs(b - d), 2));
}