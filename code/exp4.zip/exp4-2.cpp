#include <iostream>

using namespace std;

class Student {
private:
    string name, id;
    bool sex;
    int age;

public:
    Student(string name, string id, bool sex, int age) {
        this->name = name;
        this->id = id;
        this->sex = sex;
        this->age = age;
    }

    void PrintStu() {
        cout << "name:\t" << this->name << endl
             << "id:\t" << this->id << endl
             << "sex:\t" << (this->sex ? "male" : "female") << endl
             << "age:\t" << this->age << endl;
    }
};

int main() {
    Student example1 = Student("Tutu", "69724", true, 21);
    Student example2 = Student("Xiaomei", "3721", false, 20);
    example1.PrintStu();
    example2.PrintStu();
}