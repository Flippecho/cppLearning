#include <iostream>
#include <iomanip>

using namespace std;

class Time {
private:
    int hour, minute, second;

public:
    Time() {
        time_t t = time(nullptr);
        tm *now = localtime(&t);
        hour = now->tm_hour;
        minute = now->tm_min;
        second = now->tm_sec;
    }

    Time(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }

    void printMilitary() const {
        cout << setw(2) << setfill('0') << hour << ":"
             << setw(2) << setfill('0') << minute << ":"
             << setw(2) << setfill('0') << second << endl;
    }

    void printStandard() const {
        cout << setw(2) << setfill('0') << ((hour + 11) % 12 + 1) << ":"
             << setw(2) << setfill('0') << minute << ":"
             << setw(2) << setfill('0') << second
             << (hour >= 12 ? " p.m." : " a.m.") << endl;
    }
};

int main() {
    Time time1 = Time(), time2 = Time(20, 13, 14);
    cout << "time1 military: ";
    time1.printMilitary();
    cout << "time1 standard: ";
    time1.printStandard();
    cout << "time2 military: ";
    time2.printMilitary();
    cout << "time2 standard: ";
    time2.printStandard();
}