#include <iostream>

using namespace std;

class Employee {

private:
    string name, street, city, province, zip;
    string temp;

public:
    Employee(string n, string s, string c, string p, string z) {
        name = n;
        street = s;
        city = c;
        province = p;
        zip = z;
    }

    void setName(string n) {
        name = n;
    }

    void setName() {
        cout << "Please enter the name to modify(press enter to keep unchanged):" << endl;
        getline(cin, temp);
        if (temp != "") {
            name = temp;
        }
    }

    void setStreet(string s) {
        street = s;
    }

    void setStreet() {
        cout << "Please enter the street to modify(press enter to keep unchanged):" << endl;
        getline(cin, temp);
        if (temp != "") {
            street = temp;
        }
    }

    void setCity(string c) {
        city = c;
    }

    void setCity() {
        cout << "Please enter the city to modify(press enter to keep unchanged):" << endl;
        getline(cin, temp);
        if (temp != "") {
            city = temp;
        }
    }

    void setProvince(string p) {
        province = p;
    }

    void setProvince() {
        cout << "Please enter the province to modify(press enter to keep unchanged):" << endl;
        getline(cin, temp);
        if (temp != "") {
            province = temp;
        }
    }

    void setZip(string z) {
        zip = z;
    }

    void setZip() {
        cout << "Please enter the province to modify(press enter to keep unchanged):" << endl;
        getline(cin, temp);
        if (temp != "") {
            zip = temp;
        }
    }

    void reset(string n, string s, string c, string p, string z) {
        name = n;
        street = s;
        city = c;
        province = p;
        zip = z;
    }

    void reset() {
        setName();
        setStreet();
        setCity();
        setProvince();
        setZip();
    }

    void printInfo() {
        cout << "name: " << name << endl
             << "street: " << street << endl
             << "city: " << city << endl
             << "province: " << province << endl
             << "zip: " << zip << endl;
    }
};

int main() {
    Employee example = Employee("Bruce", "FM", "JX", "ZJ", "314500");
    example.printInfo();
    example.reset();
    example.printInfo();
}