#include <iostream>
using namespace std;

class Clock {
public:
    void set_clock();
    void show_clock();

    int hour, minute, second;
};

Clock t;

int main() {
    t.set_clock();
    t.show_clock();
}

void Clock::set_clock() {
    cin >> t.hour;
    cin >> t.minute;
    cin >> t.second;
}

void Clock::show_clock() {
    cout << t.hour << ":" << t.minute << ":" << t.second << endl;
}