#include <iostream>

using namespace std;

class intArray {
private:
    int *element;
    int size;

public:
    intArray(int s);

    intArray(const intArray &x);

    ~intArray();

    bool Set(int i, int elem);

    bool Get(int i, int &elem) const;

    int Length() const;

    void ReSize(int s);

    void Print();
};

intArray::intArray(int s) {
    element = new int[s]();
    size = s;
}

intArray::intArray(const intArray &x) {
    int temp;
    size = x.Length();
    element = new int[size];
    for (int i = 0; i < size; i++) {
        x.Get(i, temp);
        Set(i, temp);
    }
}

intArray::~intArray() {
    delete element;
}

bool intArray::Set(int i, int elem) {
    if (i < Length()) {
        *(element + i) = elem;
        return true;
    }
    return false;
}

bool intArray::Get(int i, int &elem) const {
    if (i < Length()) {
        elem = *(element + i);
        return true;
    }
    return false;
}

int intArray::Length() const {
    return size;
}

void intArray::ReSize(int s) {
    // bug not fixed if deleting the former array by [delete element]
    delete element;
    element = new int[s]();
    size = s;
}

void intArray::Print() {
    int *temp = element;
    for (int i = 0; i < size; i++) {
//        cout << *(element++) << " ";
        cout << *(temp++) << " ";
    }
    temp = nullptr;
    cout << endl;
}

int main() {
    intArray example(3);
    example.Set(0, 1);
    example.Set(1, 3);
    example.Set(2, 5);
    intArray copy = intArray(example);
    copy.Print();
    copy.ReSize(5);
    copy.Print();
}