#include <iostream>

using namespace std;

class Salary {
private:
    double Wage, Subsidy, Rent, WaterFee, ElecFee;

public:
    Salary() {
        Wage = Subsidy = Rent = WaterFee = ElecFee = 0;
    }

    Salary(double W, double S, double R, double WF, double EF) {
        Wage = W;
        Subsidy = S;
        Rent = R;
        WaterFee = WF;
        ElecFee = EF;
    }

    void setWage(double W) {
        Wage = W;
    }

    void setSubsidy(double S) {
        Subsidy = S;
    }

    void setRent(double R) {
        Rent = R;
    }

    void setWaterFee(double WF) {
        WaterFee = WF;
    }

    void setElecFee(double EF) {
        ElecFee = EF;
    }

    double getWage() {
        return Wage;
    }

    double getSubsidy() {
        return Subsidy;
    }

    double getRent() {
        return Rent;
    }

    double getWaterFee() {
        return WaterFee;
    }

    double getElecFee() {
        return ElecFee;
    }

    double RealSalary() {
        return Wage + Subsidy - Rent - WaterFee - ElecFee;
    }
};

int main() {
    Salary exampleA, exampleB(4500.00, 3500.00, 500.00, 34.56, 78.90);
    cout << "Check Initialization: " << exampleB.RealSalary() << endl;
    exampleA.setWage(4500.00);
    cout << "Check data assignment: " << exampleA.getWage() << endl;
}