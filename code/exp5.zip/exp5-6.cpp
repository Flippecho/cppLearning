#include <iostream>
#include <sstream>

using namespace std;

class Student {
private:
    string id;
    int score;
    static int index;

public:

    Student();

    Student(string i, int s) {
        id = i;
        score = s;
    }

    string getID() {
        return id;
    }

    int getScore() const {
        return score;
    }
};

int Student::index = 0;

Student::Student() {
    stringstream ss;
    ss << ++index;
    ss >> id;
    id = "820820100" + id;
    score = rand() % 101;
    cout << "id: " << id << "\tscore: " << score << endl;
}

void max(Student *p);

int main() {
    srand((int)time(nullptr));
    Student studentList[5];
    max(studentList);
}

void max(Student *p) {
    int max = 0, n = sizeof(*p) / sizeof(p);
    Student *m;
    for(int i = 0; i < n; i++) {
        if(p->getScore() > max) {
            max = p->getScore();
            m = p;
        }
        p = p + 1;
    }

    cout << "\nmax\tid: " << m->getID() << "\tscore: " << m->getScore() << endl;
}