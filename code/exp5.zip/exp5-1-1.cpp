#include <iostream>
using namespace std;

class A {
public:
    int m;

    // Constructor cannot have a return type
    // Clang-Tidy: Single-argument constructors must be marked explicit to avoid unintentional implicit conversions
    explicit A(int i = 0) {
        m = i;
    }

    void show() {
        cout << m;
    }

    // Destructor cannot have a return type
    ~A() {}
};

int main() {
    A a(5);
    // m is a private member of A
    a.m+=10;
    a.show();
    return 0;
}