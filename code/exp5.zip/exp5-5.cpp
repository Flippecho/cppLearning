#include <iostream>
#include <cmath>

using namespace std;

class Triangular {
private:
    double a, b, c;

public:
    Triangular(double l, double m, double n) {
        if (check(l, m, n)) {
            a = l;
            b = m;
            c = n;
        } else {
            a = 3;
            b = 4;
            c = 5;
            cout << "The given edges couldn't make a triangular, a default one(3, 4, 5) has been generated." << endl;
        }
    }

    double getPerimeter() const {
        return a + b + c;
    }

    double getArea() const;

    static bool check(double l, double m, double n) {
        double halfSum = (l + m + n) / 2;
        return halfSum > l && halfSum > m && halfSum > n;
    }

    void printInfo() const;
};

double Triangular::getArea() const {
    double p = (a + b + c) / 2;
    return sqrt(p * (p - a) * (p - b) * (p - c));
}

void Triangular::printInfo() const {
    cout << "edge a: " << a << endl
         << "edge b: " << b << endl
         << "edge c: " << c << endl
         << "perimeter: " << getPerimeter() << endl
         << "area: " << getArea() << endl;

}

int main() {
    Triangular example1(1, 2, 3), example2(2, 3, 4);
    example1.printInfo();
    example2.printInfo();
}