#include <iostream>
#include <iomanip>

using namespace std;

class Clock {
private:
    int hour, minute, second;

public:
    Clock() {
        hour = minute = second = 0;
    }

    Clock(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }

    void setHour(int h) {
        hour = h;
    }

    void setHour() {
        cout << "Please enter an integer to set the hour:" << endl;
        cin >> hour;
    }

    void setMinute(int m) {
        minute = m;
    }

    void setMinute() {
        cout << "Please enter an integer to set the minute:" << endl;
        cin >> minute;
    }

    void setSecond(int s) {
        second = s;
    }

    void setSecond() {
        cout << "Please enter an integer to set the second:" << endl;
        cin >> second;
    }

    void reset(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }

    void reset() {
        setHour();
        setMinute();
        setSecond();
    }

    void display() const;
};

void Clock::display() const {
    cout << setw(2) << setfill('0') << hour % 24 << ":"
         << setw(2) << setfill('0') << minute % 60 << ":"
         << setw(2) << setfill('0') << second % 60 << endl;
}

int main() {
    Clock ClockA, ClockB(20, 13, 14);
    cout << "Check Clock(): ";
    ClockA.display();
    cout << "Check Clock(20, 13, 14): ";
    ClockB.display();
    cout << "Check clock set manually: ";
    ClockA.setHour(123);
    ClockA.setMinute(456);
    ClockA.setSecond(789);
    ClockA.display();
    cout << "Check clock set from keyboard:" << endl;
    ClockB.reset();
    ClockB.display();
}