class X {
private:
    int a = 0;
    int b;
    int c;

    void setA(int i) { a = i; }

public:
    X() { a = b = 0; }

    X(int i) { a = i; }

    X(int i, int j, int k) {
        a = i;
        b = j;
        c = k;
    }

    void setC(int k) { c = c + k; }
};

int main() {
    X x1;
    X x2(2);
    X x3(1, 2, 3);
    x1.setC(3);
    return 0;
}
