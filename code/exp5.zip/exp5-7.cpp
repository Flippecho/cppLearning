#include <iostream>

using namespace std;

class Point {
private:
    double x, y;

public:
    Point() {
        x = y = 0;
    }

    Point(double m, double n) {
        x = m;
        y = n;
    }

    void reset(double m, double n) {
        x = m;
        y = n;
    }

    double posX() const {
        return x;
    }

    double posY() const {
        return y;
    }

    bool operator==(Point p) const {
        return p.posX() == x && p.posX() == y;
    }
};

class Rectangle {
private:
    Point pointA, pointC;

public:
    Rectangle(Point m, Point n) {
        if (m == n) {
            cout << "Same points given, points have been set to default: A(1, 2), C(3, 4)" << endl;
            pointA = Point(1, 2);
            pointC = Point(3, 4);
        } else {
            pointA = m;
            pointC = n;
        }
    }

    void displayInfo();
};

void Rectangle::displayInfo() {
    Point pointB, pointD;
    double area;
    double lenX = pointA.posX() - pointC.posX();
    double lenY = pointA.posY() - pointC.posY();

    if (lenX == 0) {    // vertical
        double len = lenY / 2;
        double center = (pointA.posY() + pointC.posY()) / 2;
        pointB.reset(pointA.posX() - len, center);
        pointD.reset(pointA.posX() + len, center);
        area = lenY * lenY / 2;
    } else if (lenY == 0) {     // horizontal
        double len = lenX / 2;
        double center = (pointA.posX() + pointC.posX()) / 2;
        pointB.reset(center, pointA.posY() - len);
        pointD.reset(center, pointA.posY() + len);
        area = lenX * lenX / 2;
    } else {    // normal
        pointB.reset(pointA.posX(), pointC.posY());
        pointD.reset(pointC.posX(), pointA.posY());
        area = lenX * lenY;
    }
    // since the answer diverse, we choose the simplest one
    cout << "point a: (" << pointA.posX() << ", " << pointA.posY() << ")" << endl;
    cout << "point b: (" << pointB.posX() << ", " << pointB.posY() << ")" << endl;
    cout << "point c: (" << pointC.posX() << ", " << pointC.posY() << ")" << endl;
    cout << "point d: (" << pointD.posX() << ", " << pointD.posY() << ")" << endl;
    cout << "area: " << area << endl;
}

int main() {
    Point a(3, 7), b(14, 21), c(14, 14);
    Rectangle example(a, b);
    example.displayInfo();
    Rectangle test(c, c);
    test.displayInfo();
}