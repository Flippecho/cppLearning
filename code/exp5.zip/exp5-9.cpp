#include <iostream>

using namespace std;

class Complex {
private:
    double real, imag;

public:
    Complex(double r, double i) {
        real = r;
        imag = i;
    }

    friend Complex add(Complex a, Complex b);

    void display() const;
};

void Complex::display() const {
    if (real == 0 && imag == 0) {
        cout << "0" << endl;
    } else if (real == 0 && imag != 0) {
        cout << imag << "i" << endl;
    } else if (real != 0 && imag == 0) {
        cout << real << endl;
    } else if (imag < 0) {
        cout << real << imag << "i" << endl;
    } else {
        cout << real << "+" << imag << "i" << endl;
    }
}

Complex add(Complex a, Complex b) {
    return Complex(a.real + b.real, a.imag + b.imag);
}

int main() {
    Complex a(-3, -2), b(6, 1);
    Complex c = add(a, b);
    c.display();
}
